package com.pranavi.productmanagementspring.model;

public interface AbstractProduct {

}
